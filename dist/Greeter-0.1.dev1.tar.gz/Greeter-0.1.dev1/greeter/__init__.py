'''
Main package for greeterpy
'''